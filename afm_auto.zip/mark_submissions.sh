#!/bin/bash

dir=testing_directory
cd $dir

OIFS="$IFS"
IFS=$'\n'

for file in `find . -type f -name "*.py"`
do	
	cp ../datafiles/A1/* .
	
	echo "Marking File" $file;
	python $file > /dev/null
done
