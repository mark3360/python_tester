#!/usr/bin/env python
# coding: utf-8

# # Assignment 2

# In[2]:


import numpy as np
import numpy_financial as npf
import pandas as pd


# ### Part A

# After your grandmother retired, she bought an annuity contract for ```cost``` dollars. The contract will pay her ```pmt``` dollars at the end of every year until she dies. The appropriate interest rate for this annuity is ```r``` per year. Write the function ```years```, which returns the number of years that your grandmother must live for in order to get more value out of the annuity than what she paid for it.

# In[3]:


def years(cost,pmt,r):
    number_of_year = (np.log(pmt/(pmt-cost*r)))/np.log(1+r)
    return number_of_year
print(years(250000,30000,0.06))


# ### Part B

# There are 100,000 securities. 
# Each security generates cashflows every year for sthat represents a file path to a csv file formatted like the one suppliedome years. 
# Every year, security generates different cashflows. 
# 
# Each row corresponds to a different security.
# Col A: security number
# Col B-Col K: different cashflows for different years
# Col L: current price
# 
# Which security has the smallest IRR?
# Which security has the largest IRR?
# 
# 
# Write the function ```IRR```, which returns a list of size 2. The first element will be the number of the security with the lowest IRR, and the second element will be the number of the security with the highest IRR. Like the previous assignment, it will also take in a string that represents a file path to a csv file formatted like the one supplied.
# 
# Note: The numpy-financial library contains the function irr, which you may find useful for this assignment. You can see the sample use of this function here: https://numpy.org/numpy-financial/latest/irr.html

# In[18]:


def IRR(path):
    df = pd.read_csv(path) # Do not change the first two lines of this function
    # Write your solution here
    start = df['id'].min()
    end = df['id'].max()
    i_d = df['id']
    y1 = np.nan_to_num(df["year1"],0)
    y2 = np.nan_to_num(df["year2"],0)
    y3 = np.nan_to_num(df["year3"],0)
    y4 = np.nan_to_num(df["year4"],0)
    y5 = np.nan_to_num(df["year5"],0)
    y6 = np.nan_to_num(df["year6"],0)
    y7 = np.nan_to_num(df["year7"],0)
    y8 = np.nan_to_num(df["year8"],0)
    y9 = np.nan_to_num(df["year9"],0)
    y10 = np.nan_to_num(df["year10"],0)
    cp = np.nan_to_num(df["currentprice"],0)
    maxi = 0
    mini = 0
    maxid = 0
    minid = 0
    for i in range(start, end+1):
        crid = i_d[i]
        irr = round(npf.irr([-cp[i], y1[i], y2[i], y3[i], y4[i], y5[i], y6[i], y7[i], y8[i], y9[i], y10[i]]), 5)
        if i == start:
            maxi = irr
            mini = irr
        else:
            if irr >= maxi:
                maxi = irr
                maxid = crid
            if irr < mini:
                mini = irr
                minid = crid
    print("smallest " + str(mini) + "\n" + "largest " + str(maxi))
    return [minid, maxid]


# In[ ]:




