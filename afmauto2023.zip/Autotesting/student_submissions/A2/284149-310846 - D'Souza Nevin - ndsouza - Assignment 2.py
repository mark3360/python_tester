#!/usr/bin/env python
# coding: utf-8

# # Assignment 2

# In[21]:


import numpy as np
import pandas as pd
import numpy_financial as npf


# ### Part A

# After your grandmother retired, she bought an annuity contract for ```cost``` dollars. The contract will pay her ```pmt``` dollars at the end of every year until she dies. The appropriate interest rate for this annuity is ```r``` per year. Write the function ```years```, which returns the number of years that your grandmother must live for in order to get more value out of the annuity than what she paid for it.

# In[19]:


def years(cost,pmt,r):
    # Write your solution here
    n = 0
    pv = 0
    while pv < cost:
        n = n + 1
        pv += pmt/(1+r)**n 
    return n


# ### Part B

# There are 100,000 securities. 
# Each security generates cashflows every year for sthat represents a file path to a csv file formatted like the one suppliedome years. 
# Every year, security generates different cashflows. 
# 
# Each row corresponds to a different security.
# Col A: security number
# Col B-Col K: different cashflows for different years
# Col L: current price
# 
# Which security has the smallest IRR?
# Which security has the largest IRR?
# 
# 
# Write the function ```IRR```, which returns a list of size 2. The first element will be the number of the security with the lowest IRR, and the second element will be the number of the security with the highest IRR. Like the previous assignment, it will also take in a string that represents a file path to a csv file formatted like the one supplied.
# 
# Note: The numpy-financial library contains the function irr, which you may find useful for this assignment. You can see the sample use of this function here: https://numpy.org/numpy-financial/latest/irr.html

# In[22]:


def IRR(path):
    df = pd.read_csv(path) # Do not change the first two lines of this function
    # Write your solution here
    numpyirrmax = float('-inf')
    numpyirrmin = float('inf')

    for index, row in df.iterrows():
        security_number = row["id"]
        currentprice = df.loc[index, "currentprice"]
        cf1 = df.loc[index, "year1"]
        cf2 = df.loc[index, "year2"]
        cf3 = df.loc[index, "year3"]
        cf4 = df.loc[index, "year4"]
        cf5 = df.loc[index, "year5"]
        cf6 = df.loc[index, "year6"]
        cf7 = df.loc[index, "year7"]
        cf8 = df.loc[index, "year8"]
        cf9 = df.loc[index, "year9"]
        cf10 = df.loc[index, "year10"]
        cashflows = [cf1, cf2, cf3, cf4, cf5, cf6, cf7, cf8, cf9, cf10]
        cleanedList = [x for x in cashflows if str(x) != 'nan']

        
        numpyirrlist = [-currentprice] + cleanedList
        numpyirr = npf.irr(numpyirrlist)
        

        if numpyirr >= numpyirrmax:
            numpyirrmax = numpyirr
            numpymaxanswer = security_number
        
        if numpyirr <= numpyirrmin:
            numpyirrmin = numpyirr
            numpyminanswer = security_number
            
    return [int(numpyminanswer), int(numpymaxanswer)]


# In[ ]:




