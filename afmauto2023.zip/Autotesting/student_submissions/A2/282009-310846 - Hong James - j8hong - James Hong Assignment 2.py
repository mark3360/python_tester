#!/usr/bin/env python
# coding: utf-8

# # Assignment 2

# In[1]:


import numpy as np
import numpy_financial as npf
import pandas as pd


# ### Part A

# After your grandmother retired, she bought an annuity contract for ```cost``` dollars. The contract will pay her ```pmt``` dollars at the end of every year until she dies. The appropriate interest rate for this annuity is ```r``` per year. Write the function ```years```, which returns the number of years that your grandmother must live for in order to get more value out of the annuity than what she paid for it.

# In[2]:


def years(cost,pmt,r):
    # Write your solution here
    n = 0
    while True:
        # calculate the present value
        PV = (pmt / r) * (1 - (1 / (1 + r) ** n))
        # check if the present value is higher than cost
        if PV > cost:
            return n
        n += 1 


# In[3]:


years(250000,30000,0.06)


# ### Part B

# There are 100,000 securities. 
# Each security generates cashflows every year for sthat represents a file path to a csv file formatted like the one suppliedome years. 
# Every year, security generates different cashflows. 
# 
# Each row corresponds to a different security.
# Col A: security number
# Col B-Col K: different cashflows for different years
# Col L: current price
# 
# Which security has the smallest IRR?
# Which security has the largest IRR?
# 
# 
# Write the function ```IRR```, which returns a list of size 2. The first element will be the number of the security with the lowest IRR, and the second element will be the number of the security with the highest IRR. Like the previous assignment, it will also take in a string that represents a file path to a csv file formatted like the one supplied.
# 
# Note: The numpy-financial library contains the function irr, which you may find useful for this assignment. You can see the sample use of this function here: https://numpy.org/numpy-financial/latest/irr.html

# In[51]:


def IRR(path):
    df = pd.read_csv(path) # Do not change the first two lines of this function
    # Write your solution here
    
    # replace all the NaN values with zero
    df.fillna(0,inplace=True)
    
    # declare variables
    smallest_irr = float('inf')
    largest_irr = -float('inf')
    smallest_security = None
    largest_security = None

    # Iterate through each row in the DataFrame.
    for index, row in df.iterrows():
        
        # fetch the data for each security
        security_number = row['id']
        cashflows = row[['year1', 'year2', 'year3', 'year4', 'year5', 'year6', 'year7', 'year8', 'year9', 'year10']].tolist()
        current_price = row['currentprice']
        
         # Calculate the IRR for the cashflows and current price.
        irr = npf.irr([-current_price] + cashflows)
        
        # Check if this security has the smallest or largest IRR.
        if irr < smallest_irr:
            smallest_irr = irr
            smallest_security = security_number

        if irr > largest_irr:
            largest_irr = irr
            largest_security = security_number

    return [smallest_security, largest_security]


# In[52]:



