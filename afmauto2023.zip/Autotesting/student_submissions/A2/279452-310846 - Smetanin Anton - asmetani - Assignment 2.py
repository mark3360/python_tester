#!/usr/bin/env python
# coding: utf-8

# # Assignment 2

# In[1]:


import numpy as np
import numpy_financial as npf
import pandas as pd


# ### Part A

# After your grandmother retired, she bought an annuity contract for ```cost``` dollars. The contract will pay her ```pmt``` dollars at the end of every year until she dies. The appropriate interest rate for this annuity is ```r``` per year. Write the function ```years```, which returns the number of years that your grandmother must live for in order to get more value out of the annuity than what she paid for it.

# In[2]:


def years(cost, pmt, r):
    return float(npf.nper(r, pmt, -cost))


# ### Part B

# There are 100,000 securities. 
# Each security generates cashflows every year for sthat represents a file path to a csv file formatted like the one suppliedome years. 
# Every year, security generates different cashflows. 
# 
# Each row corresponds to a different security.
# Col A: security number
# Col B-Col K: different cashflows for different years
# Col L: current price
# 
# Which security has the smallest IRR?
# Which security has the largest IRR?
# 
# 
# Write the function ```IRR```, which returns a list of size 2. The first element will be the number of the security with the lowest IRR, and the second element will be the number of the security with the highest IRR. Like the previous assignment, it will also take in a string that represents a file path to a csv file formatted like the one supplied.
# 
# Note: The numpy-financial library contains the function irr, which you may find useful for this assignment. You can see the sample use of this function here: https://numpy.org/numpy-financial/latest/irr.html

# In[76]:


def IRR(path):
    df = pd.read_csv(path) # Do not change the first two lines of this function
    df.set_index('id', inplace=True)
    df['irr'] = df.apply(lambda x: x.dropna().tolist(), axis=1)
    df['irr'] = df['irr'].apply(lambda x: npf.irr([-x[-1]] + x[:-1]))
    return [df['irr'].idxmin(), df['irr'].idxmax()]


# In[ ]:




