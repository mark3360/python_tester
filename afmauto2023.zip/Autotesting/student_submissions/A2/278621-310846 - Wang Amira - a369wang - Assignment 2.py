#!/usr/bin/env python
# coding: utf-8

# # Assignment 2

# In[1]:


import numpy as np
import numpy_financial as npf
import pandas as pd


# ### Part A

# After your grandmother retired, she bought an annuity contract for ```cost``` dollars. The contract will pay her ```pmt``` dollars at the end of every year until she dies. The appropriate interest rate for this annuity is ```r``` per year. Write the function ```years```, which returns the number of years that your grandmother must live for in order to get more value out of the annuity than what she paid for it.

# In[2]:


def years(cost,pmt,r):
    n=0
    pv=0
    while pv<cost:
        n=n+1
        pv=pmt*((1-(1/(1+r)**n))/r)
    return n


# ### Part B

# In[3]:


def IRR(path):
    df=pd.read_csv(path)
    start=df["id"].min()
    end=df["id"].max()
    security=df["id"]
    year1=np.nan_to_num(df["year1"],0)
    year2=np.nan_to_num(df["year2"],0)
    year3=np.nan_to_num(df["year3"],0)
    year4=np.nan_to_num(df["year4"],0)
    year5=np.nan_to_num(df["year5"],0)
    year6=np.nan_to_num(df["year6"],0)
    year7=np.nan_to_num(df["year7"],0)
    year8=np.nan_to_num(df["year8"],0)
    year9=np.nan_to_num(df["year9"],0)
    year10=np.nan_to_num(df["year10"],0)
    cp=np.nan_to_num(df["currentprice"],0)
    smallestId=start
    biggestId=start
    smallestvalue=0
    biggestvalue=0
    for i in range(start, end):
        currentId=security[i]
        yearnum=0
        for x in range (0,11):
            if ((df.iloc[i,x+1]) !=0):
                yearnum=yearnum+1
        irr=round(npf.irr([-cp[i],year1[i],year2[i],year3[i],year4[i],year5[i],year6[i],year7[i],year8[i],year9[i],year10[i]]),yearnum)
        if i==start:
            smallestvalue=irr
            biggestvalue=irr
        else:
            if irr<smallestvalue:
                smallestvalue=irr
                smallestId=currentId
            if irr>biggestvalue:
                biggestvalue=irr
                biggestId=currentId
    lst=[smallestId, biggestId]
    return lst

