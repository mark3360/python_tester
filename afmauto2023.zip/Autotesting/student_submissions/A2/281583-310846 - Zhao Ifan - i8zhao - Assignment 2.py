#!/usr/bin/env python
# coding: utf-8

# # Assignment 2

# In[1]:


import numpy as np
import numpy_financial as npf
import pandas as pd


# ### Part A

# After your grandmother retired, she bought an annuity contract for ```cost``` dollars. The contract will pay her ```pmt``` dollars at the end of every year until she dies. The appropriate interest rate for this annuity is ```r``` per year. Write the function ```years```, which returns the number of years that your grandmother must live for in order to get more value out of the annuity than what she paid for it.

# In[2]:


def years(cost,pmt,r):
    # Write your solution here
    # PV = C / r [1 - 1/(1+r)^n], and we want to find n
    # PV = cost, when you'd get the same value out of the annuity as when you pay for it
    # PV * r / C = 1 - 1/(1+r)^n
    # 1 - PV * r/C = 1/(1+r)^n
    # 1 / (1 - PV * r/C) = (1+r)^n
    # ln both sides
    # ln[1 / (1 - PV * r/C)] = ln[(1+r)^n] = n ln(1 + r)
    # ln[1 / (1 - PV * r/C)] / ln(1 + r) = n
    # [ln(1) - ln (1 - PV * r/C)] / ln (1 + r) = n
    # ln (1 - PV * r/C) / ln (1 + r) = n
    years = np.log(1 - cost * (r / pmt)) / np.log(1 + r) # np.log() is base e, ln()
    if (np.ceil(years) == years): 
        years += 1 # Because we want the years needed to get MORE value out of the annuity than she paid for it
    
    return np.ceil(years)


# ### Part B

# There are 100,000 securities. 
# Each security generates cashflows every year for sthat represents a file path to a csv file formatted like the one suppliedome years. 
# Every year, security generates different cashflows. 
# 
# Each row corresponds to a different security.
# Col A: security number
# Col B-Col K: different cashflows for different years
# Col L: current price
# 
# Which security has the smallest IRR?
# Which security has the largest IRR?
# 
# 
# Write the function ```IRR```, which returns a list of size 2. The first element will be the number of the security with the lowest IRR, and the second element will be the number of the security with the highest IRR. Like the previous assignment, it will also take in a string that represents a file path to a csv file formatted like the one supplied.
# 
# Note: The numpy-financial library contains the function irr, which you may find useful for this assignment. You can see the sample use of this function here: https://numpy.org/numpy-financial/latest/irr.html

# In[3]:


def IRR(path):
    df = pd.read_csv(path) # Do not change the first two lines of this function
    # Write your solution here
    # npf.irr calculates irr with a list of cashflows (the first generally being negative for the ititial payment)
    irrs = pd.DataFrame(df["currentprice"])
    #display(irrs)
    for index, row in df.iterrows():
        cashflows = [-irrs.iloc[index, 0]]
        for i in range(1, 11):
            if np.isnan(row[i]):
                cashflows.insert(i, 0)
            else:
                cashflows.insert(i, row[i])
        
        irrs.iloc[index, 0] = npf.irr(cashflows)
        #print(cashflows)
        #print(irrs.iloc[index, 0])
    
    smallest = [0, irrs.iloc[0, 0]]
    largest = [0, irrs.iloc[0, 0]]
    for index, row in irrs.iterrows():
        irr = row[0]
        if irr < smallest[1]:
            smallest[0] = index
            smallest[1] = irr
        elif irr > largest[1]:
            largest[0] = index
            largest[1] = irr
    
    return [smallest[0], largest[0]]



# In[ ]:




