#!/usr/bin/env python
# coding: utf-8

# In[9]:


import numpy as np
import pandas as pd


# In[7]:


def years(cost,pmt,r):
    x = r*cost/pmt
    y = 1-x
    z = np.log(y)
    m = 1/(1+r)
    n = np.log(m)
    p = z/n
    return p
print(years(12,4,0.04))


# In[10]:


def IRR(path):
    df = pd.read_csv(path) # Do not change the first two lines of this function
    
    # getting dictionary of IRR values with attached names
    directory = dict()
    for index, row in dataframe.iterrows():
        total = npf.IRR(row['B'], row['L']) + row['C'] + row['D'] + row['E'] + row['F'] + row['G'] + row['H'] + row['I'] + row['J'] + row['K']
        scaled_total = total/10
        premium = row['L']
        risk = premium + 0.3
        price = scaled_total/(1+risk)
        new_key = row['Col A'] 
        directory["new_key"] = price
    
    #finding smallest from our dictionary
    value = directory.values()
    min_val = min(value)
    index_of_min = value.index(min_val)
    key = directory.keys()
    min_sec = key[index_of_min]
    
    #finding largest from our dictionary
    values = directory.values()
    max_val = max(values)
    index_of_max = values.index(max_val)
    keys = directory.keys()
    max_sec = keys[index_of_max]
        
    return [min_sec, max_sec]


# In[ ]:




