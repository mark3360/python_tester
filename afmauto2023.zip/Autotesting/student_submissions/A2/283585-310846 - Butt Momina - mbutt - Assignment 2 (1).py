#!/usr/bin/env python
# coding: utf-8

# # Assignment 2

# In[5]:


import numpy as np
import numpy_financial as npf
import pandas as pd


# ### Part A

# After your grandmother retired, she bought an annuity contract for ```cost``` dollars. The contract will pay her ```pmt``` dollars at the end of every year until she dies. The appropriate interest rate for this annuity is ```r``` per year. Write the function ```years```, which returns the number of years that your grandmother must live for in order to get more value out of the annuity than what she paid for it.

# In[6]:


def years(cost,pmt,r):
    
    n = np.log(1 / (1 - ((cost/pmt)*r))) / np.log(1 + r)
    
    return n


# ### Part B

# There are 100,000 securities. 
# Each security generates cashflows every year for sthat represents a file path to a csv file formatted like the one suppliedome years. 
# Every year, security generates different cashflows. 
# 
# Each row corresponds to a different security.
# Col A: security number
# Col B-Col K: different cashflows for different years
# Col L: current price
# 
# Which security has the smallest IRR?
# Which security has the largest IRR?
# 
# 
# Write the function ```IRR```, which returns a list of size 2. The first element will be the number of the security with the lowest IRR, and the second element will be the number of the security with the highest IRR. Like the previous assignment, it will also take in a string that represents a file path to a csv file formatted like the one supplied.
# 
# Note: The numpy-financial library contains the function irr, which you may find useful for this assignment. You can see the sample use of this function here: https://numpy.org/numpy-financial/latest/irr.html

# In[3]:


def IRR(path):
    df = pd.read_csv(path) # Do not change the first two lines of this function
    df.fillna(0, inplace=True)
    
     # Initialize variables to keep track of min and max IRR and corresponding security numbers
    min_irr = float('inf')  # start with positive infinity
    max_irr = float('-inf')  # start with negative infinity
    min_irr_security = None
    max_irr_security = None
    
    # Iterate through each security's cash flows to compute the IRR
    for index, row in df.iterrows():
        # Combine cashflows and current price for IRR calculation
        cashflows = row[1:-1].tolist() + [-row[-1]]  # current price is considered as negative cash flow (as an investment)
        current_irr = npf.irr(cashflows)
        
        if current_irr < min_irr:
            min_irr = current_irr
            min_irr_security = row[0]
        
        if current_irr > max_irr:
            max_irr = current_irr
            max_irr_security = row[0]
    
    return [min_irr_security, max_irr_security]

