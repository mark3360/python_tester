#!/usr/bin/env python
# coding: utf-8

# # Assignment 2

# In[2]:


import numpy as np
import numpy_financial as npf
import pandas as pd


# ### Part A

# After your grandmother retired, she bought an annuity contract for ```cost``` dollars. The contract will pay her ```pmt``` dollars at the end of every year until she dies. The appropriate interest rate for this annuity is ```r``` per year. Write the function ```years```, which returns the number of years that your grandmother must live for in order to get more value out of the annuity than what she paid for it.

# In[6]:


def years(cost,pmt,r):
    a = ((r * cost) / pmt) - 1
    num_years = np.log((-1/a)) / np.log(1 + r)
    return num_years


# ### Part B

# There are 100,000 securities. 
# Each security generates cashflows every year for sthat represents a file path to a csv file formatted like the one suppliedome years. 
# Every year, security generates different cashflows. 
# 
# Each row corresponds to a different security.
# Col A: security number
# Col B-Col K: different cashflows for different years
# Col L: current price
# 
# Which security has the smallest IRR?
# Which security has the largest IRR?
# 
# 
# Write the function ```IRR```, which returns a list of size 2. The first element will be the number of the security with the lowest IRR, and the second element will be the number of the security with the highest IRR. Like the previous assignment, it will also take in a string that represents a file path to a csv file formatted like the one supplied.
# 
# Note: The numpy-financial library contains the function irr, which you may find useful for this assignment. You can see the sample use of this function here: https://numpy.org/numpy-financial/latest/irr.html

# In[3]:


def IRR(path):
    df = pd.read_csv(path) # Do not change the first two lines of this function
    find = []
    
    for index, row in df.iterrows():
        sum_cashflows = [-(row[11])]
        for i in range(1, 11):
            if pd.isna(row['year' + str(i)]) == True:
                row['year' + str(i)] = 0
            sum_cashflows = sum_cashflows + [row['year' + str(i)]]
        irr = npf.irr(sum_cashflows)
        find = find + [irr]

    max_ = find.index(max(find))
    min_ = find.index(min(find))
    final = [min_, max_]
    
    return final


# In[ ]:




# In[ ]:




# In[ ]:




# In[1]:




# In[4]:




# In[1]:




# In[4]:




# In[5]:


years(250000, 30000, 0.04)


# In[7]:


years(250000, 30000, 0.04)


# In[8]:


years(250000, 30000, 0.06)


# In[ ]:




