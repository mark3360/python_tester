#!/usr/bin/env python
# coding: utf-8

# # Assignment 2

# In[56]:


import numpy as np
import numpy_financial as npf
import pandas as pd


# ### Part A

# After your grandmother retired, she bought an annuity contract for ```cost``` dollars. The contract will pay her ```pmt``` dollars at the end of every year until she dies. The appropriate interest rate for this annuity is ```r``` per year. Write the function ```years```, which returns the number of years that your grandmother must live for in order to get more value out of the annuity than what she paid for it.

# In[57]:


def years(cost,pmt,r):
    #We rearrange the formula cost = pmt * 1/r * [1 - 1/r^n]
    #r * cost/pmt = 1 - 1/r^n
    #r * cost/pmt - 1 = -1/r^n
    # -1/(r * cost/pmt - 1) = r^n
    #ln(-1/(r * cost/pmt - 1)) = ln(r^n) = nln(r)
    #ln(-1/(r * cost/pmt - 1))/ln(r) = n
    
    # We return the years as an integer since payments are received at the end of each year.
    # Because of this we also ensure always rounding up, using the np.ceil function
    # The np.ceil function only works on arrays so we convert the float answer to a length 1 array 
    # and then index out the result and convert it to an int form.
    return int(np.ceil([((np.log(-1/(((cost/pmt) * r) - 1)))/(np.log(1+r)))])[0])


# ### Part B

# There are 100,000 securities. 
# Each security generates cashflows every year for sthat represents a file path to a csv file formatted like the one suppliedome years. 
# Every year, security generates different cashflows. 
# 
# Each row corresponds to a different security.
# Col A: security number
# Col B-Col K: different cashflows for different years
# Col L: current price
# 
# Which security has the smallest IRR?
# Which security has the largest IRR?
# 
# 
# Write the function ```IRR```, which returns a list of size 2. The first element will be the number of the security with the lowest IRR, and the second element will be the number of the security with the highest IRR. Like the previous assignment, it will also take in a string that represents a file path to a csv file formatted like the one supplied.
# 
# Note: The numpy-financial library contains the function irr, which you may find useful for this assignment. You can see the sample use of this function here: https://numpy.org/numpy-financial/latest/irr.html

# In[58]:


def IRR(path):
    # Read in the csv file and fill all NaN values with 0, as these values only exist in the cashflow columns
    # Additional cashflows of 0 do not affect the IRR function as these cashflows will not add anything to the PV of
    # the overall cashflows.
    df = pd.read_csv(path)
    df = df.fillna(0)
    
    #Iterate through the dataframe rows and place the calculated irr value for each security in a list.
    lst_irrs = []
    for i in df.index:
        lst_irrs.append(npf.irr([-df.loc[i, 'currentprice'], df.loc[i, 'year1'], df.loc[i,'year2'], df.loc[i,'year3'], df.loc[i,'year4'], df.loc[i,'year5'], df.loc[i,'year6'], df.loc[i,'year7'], df.loc[i,'year8'],df.loc[i,'year9'], df.loc[i,'year10']]))
    
    #add the calculated irr's to the corresponding column in the dataframe.
    df['IRR'] = lst_irrs
    
    #Grab the index of the minimum and maximum IRR's across the 100,000 securities.
    return [lst_irrs.index(min(lst_irrs)), lst_irrs.index(max(lst_irrs))]

