#!/usr/bin/env python
# coding: utf-8

# # Assignment 2

# In[1]:


import numpy as np
import numpy_financial as npf
import pandas as pd


# ### Part A

# After your grandmother retired, she bought an annuity contract for ```cost``` dollars. The contract will pay her ```pmt``` dollars at the end of every year until she dies. The appropriate interest rate for this annuity is ```r``` per year. Write the function ```years```, which returns the number of years that your grandmother must live for in order to get more value out of the annuity than what she paid for it.

# In[2]:


def years(cost,pmt,r):
    x = (cost * r) / pmt
    y = 1/(1-x)
    
    return np.log(y)/np.log(1+r)


# ### Part B

# There are 100,000 securities. 
# Each security generates cashflows every year for sthat represents a file path to a csv file formatted like the one suppliedome years. 
# Every year, security generates different cashflows. 
# 
# Each row corresponds to a different security.
# Col A: security number
# Col B-Col K: different cashflows for different years
# Col L: current price
# 
# Which security has the smallest IRR?
# Which security has the largest IRR?
# 
# 
# Write the function ```IRR```, which returns a list of size 2. The first element will be the number of the security with the lowest IRR, and the second element will be the number of the security with the highest IRR. Like the previous assignment, it will also take in a string that represents a file path to a csv file formatted like the one supplied.
# 
# Note: The numpy-financial library contains the function irr, which you may find useful for this assignment. You can see the sample use of this function here: https://numpy.org/numpy-financial/latest/irr.html

# In[3]:


def IRR(path):
    df = pd.read_csv(path) # Do not change the first two lines of this function
    df['year1'] = df['year1'].fillna(0)
    df['year2'] = df['year2'].fillna(0)
    df['year3'] = df['year3'].fillna(0)
    df['year4'] = df['year4'].fillna(0)
    df['year5'] = df['year5'].fillna(0)
    df['year6'] = df['year6'].fillna(0)
    df['year7'] = df['year7'].fillna(0)
    df['year8'] = df['year8'].fillna(0)
    df['year9'] = df['year9'].fillna(0)
    df['year10'] = df['year10'].fillna(0)
    df['price'] = -df['currentprice']
    df['IRR'] = df['year1'] + df['year2'] + df['year3'] + df['year4'] + df['year5'] + df['year6'] + df['year7'] + df['year8'] + df['year9'] + df['year10']
    
    df['actualIRR'] = df.apply(lambda row: npf.irr([row['price'], row['year1'], row['year2'], row['year3'], row['year4'], row['year5'], row['year6'], row['year7'], row['year8'], row['year9'], row['year10']]), axis=1)
    
    return [df['actualIRR'].idxmin(), df['actualIRR'].idxmax()]


# In[4]:




# In[ ]:




